/* -*- Mode: C; tab-width: 8; indent-tabs-mode: t; c-basic-offset: 8 -*- */
#ifndef __GLADE_DEBUG_H__
#define __GLADE_DEBUG_H__

LIBGLADEUI_API void glade_setup_log_handlers (void);

#endif /* __GLADE-DEBUG_H__ */
