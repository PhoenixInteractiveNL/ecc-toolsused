/* --------------------------------------------------------------------------
 * ZIPFind - Written by Logiqx (http://www.logiqx.com/)
 *
 * Little tool that tries to find ZIP files that you need!
 * -------------------------------------------------------------------------- */

/* --- Function protoypes --- */

int game_report(struct dat *, struct dat *, int);
int zip_report(struct dat *, struct dat *, int);
int url_report(struct dat *, char *);
