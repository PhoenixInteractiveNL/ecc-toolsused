Put the required MAME ROMs in this directory.
